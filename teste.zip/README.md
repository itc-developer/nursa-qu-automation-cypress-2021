# nursa-qa-automation-cypress-2021

## setup
0. nvm use v15.14.0
1. npm install
2. npm run cypress:open
