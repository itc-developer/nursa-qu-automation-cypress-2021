module.exports = {
  extends: [
    'stylelint-config-recommended-scss',
    'stylelint-config-idiomatic-order'
  ]
}
